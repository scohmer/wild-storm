import random
#python program to convert binary to decimal

def decimalToBinary(n):
    return bin(n)[2:].replace("0b", "").zfill(8)

if __name__ == '__main__':
    rNum = random.randint(0, 255)

    #begin user input validation

    while True:
        try:
            userInput1 = input("Convert " + str(decimalToBinary(rNum)) + " to decimal: ")
            if(int(userInput1) == int(rNum)):
                rNum = random.randint(0, 255)
                userInput2 = input("Convert " + str(decimalToBinary(rNum)) + " to decimal: ")
                if(int(userInput2) == int(rNum)):
                    rNum = random.randint(0, 255)
                    userInput3 = input("Convert " + str(decimalToBinary(rNum)) + " to decimal: ")
                    if(int(userInput3) == int(rNum)):
                        flag = int(userInput1) + int(userInput2) + int(userInput3)
                        hexFlag = hex(int(flag))
                        print("Your flag is: " + str(hexFlag))
                    else:
                        print("Try again")
                else:
                    print("Try again")
            else:
                print("Try again")
        except ValueError:
            print("Bad input.")
            continue
        else:
            break

    #end user input validation

